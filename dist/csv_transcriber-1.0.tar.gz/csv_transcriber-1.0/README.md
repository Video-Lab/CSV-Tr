# CSV-Transcriber
Breaks down a CSV file into text files containing the contents of each row.

## Installation
TBA

## Usage
TBA

## License
A short snippet describing the license (MIT, Apache etc)

MIT © Jad Khalili 2019.
